FORTIVON IT WEBSITE

Files
- index.html
- styles.css
- script.js
- logo.png

Contact setup
The website displays info@fortivonit.com throughout the contact areas. The inquiry form uses a mailto workflow: when a visitor submits it, their default email application opens with the inquiry addressed to info@fortivonit.com.

Important
This does not send mail silently from the website itself. For a true web form that submits directly in the browser without opening an email app, connect the form to a service such as Microsoft Forms/Power Automate, Formspree, or a website backend.
